import 'package:flutter/material.dart';
import 'db_helper.dart';

class LogProvider extends ChangeNotifier {
  List<Map<String, dynamic>> _logs = [];

  List<Map<String, dynamic>> get logs => _logs;

  Future<void> fetchLogs() async {
    final data = await DatabaseHelper().getLogs();
    _logs = data;
    notifyListeners();
  }

  Future<void> addLog(String category) async {
    await DatabaseHelper().insertLog(category);
    await fetchLogs();
  }
}
