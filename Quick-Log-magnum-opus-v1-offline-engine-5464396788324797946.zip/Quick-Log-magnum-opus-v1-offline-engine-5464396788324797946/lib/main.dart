import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme/app_theme.dart';
import 'features/vault/presentation/vault_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const ProviderScope(
      child: MagnumOpusApp(),
    ),
  );
}

class MagnumOpusApp extends StatelessWidget {
  const MagnumOpusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Magnum Opus Vault',
      theme: AppTheme.darkTheme,
      home: const VaultScreen(),
    );
  }
}
