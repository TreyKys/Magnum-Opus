import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static const _databaseName = "magnum_vault.db";
  static const _databaseVersion = 1;

  static const tableDocuments = 'documents';
  static const columnId = 'id';
  static const columnTitle = 'title';
  static const columnFilePath = 'file_path';
  static const columnFileSizeMb = 'file_size_mb';
  static const columnTotalPages = 'total_pages';
  static const columnLastAccessed = 'last_accessed';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $tableDocuments (
        $columnId TEXT PRIMARY KEY,
        $columnTitle TEXT NOT NULL,
        $columnFilePath TEXT NOT NULL,
        $columnFileSizeMb REAL NOT NULL,
        $columnTotalPages INTEGER NOT NULL,
        $columnLastAccessed TEXT NOT NULL
      )
    ''');
  }

  Future<void> insertDocument(Map<String, dynamic> row) async {
    Database db = await instance.database;
    await db.insert(tableDocuments, row, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> getAllDocuments() async {
    Database db = await instance.database;
    return await db.query(tableDocuments, orderBy: '$columnLastAccessed DESC');
  }

  Future<int> deleteDocument(String id) async {
    Database db = await instance.database;
    return await db.delete(
      tableDocuments,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }
}
