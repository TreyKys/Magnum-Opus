import 'package:flutter/material.dart';

class AppTheme {
  static const Color scaffoldBackgroundColor = Color(0xFF121212);
  static const Color neonAccent = Color(0xFF00E5FF); // Cyan
  static const Color cardColor = Color(0xFF1E1E1E);

  static ThemeData get darkTheme {
    return ThemeData.dark().copyWith(
      scaffoldBackgroundColor: scaffoldBackgroundColor,
      colorScheme: const ColorScheme.dark(
        primary: neonAccent,
        secondary: neonAccent,
        surface: cardColor,
      ).copyWith(surface: scaffoldBackgroundColor),
      appBarTheme: const AppBarTheme(
        backgroundColor: scaffoldBackgroundColor,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: neonAccent,
        foregroundColor: Colors.black,
      ),
      cardTheme: CardThemeData(
        color: cardColor,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Colors.white),
        bodyMedium: TextStyle(color: Colors.white70),
        titleLarge: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      ),
    );
  }
}
