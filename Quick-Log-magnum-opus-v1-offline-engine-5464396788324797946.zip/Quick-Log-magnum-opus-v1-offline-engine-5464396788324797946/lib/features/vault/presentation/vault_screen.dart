import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../providers/file_ingestion_service.dart';
import '../providers/vault_provider.dart';
import 'pdf_viewer_screen.dart';

class VaultScreen extends ConsumerWidget {
  const VaultScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final documents = ref.watch(vaultProvider);
    final isIngesting = ref.watch(isIngestingProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('MAGNUM OPUS'),
      ),
      body: documents.isEmpty
          ? Center(
              child: Text(
                'No documents yet.\nSpeed to Insight starts here.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            )
          : ListView.builder(
              itemCount: documents.length,
              itemBuilder: (context, index) {
                final doc = documents[index];
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    title: Text(
                      doc.title,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      '${doc.fileSizeMb.toStringAsFixed(2)} MB • ${doc.totalPages} Pages',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.white54),
                      onPressed: () {
                        ref.read(vaultProvider.notifier).removeDocument(doc);
                      },
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PdfViewerScreen(document: doc),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: isIngesting
            ? null
            : () async {
                await ref.read(fileIngestionServiceProvider).ingestPdf();
              },
        backgroundColor: isIngesting ? Colors.grey : AppTheme.neonAccent,
        child: isIngesting
            ? const CircularProgressIndicator(color: Colors.black)
            : const Icon(Icons.add),
      ),
    );
  }
}
