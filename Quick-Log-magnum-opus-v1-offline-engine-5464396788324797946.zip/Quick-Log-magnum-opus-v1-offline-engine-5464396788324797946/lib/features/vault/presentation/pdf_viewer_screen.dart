import 'dart:io';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../domain/document.dart';

class PdfViewerScreen extends StatelessWidget {
  final Document document;

  const PdfViewerScreen({super.key, required this.document});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          document.title,
          style: const TextStyle(fontSize: 16),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Center(
              child: Text(
                '${document.totalPages} Pages',
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ),
          )
        ],
      ),
      body: SfPdfViewer.file(
        File(document.filePath),
        canShowScrollHead: false,
        canShowScrollStatus: false,
      ),
    );
  }
}
