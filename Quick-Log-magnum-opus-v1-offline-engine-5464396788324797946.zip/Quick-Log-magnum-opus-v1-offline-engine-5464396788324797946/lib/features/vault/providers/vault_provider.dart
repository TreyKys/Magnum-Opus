import "dart:io" as dart_io;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/database/database_helper.dart';
import '../domain/document.dart';

final vaultProvider = NotifierProvider<VaultNotifier, List<Document>>(() {
  return VaultNotifier();
});

class VaultNotifier extends Notifier<List<Document>> {
  @override
  List<Document> build() {
    loadDocuments();
    return const [];
  }

  Future<void> loadDocuments() async {
    final docsData = await DatabaseHelper.instance.getAllDocuments();
    final docs = docsData.map((data) => Document.fromMap(data)).toList();
    state = docs;
  }

  Future<void> addDocument(Document doc) async {
    await DatabaseHelper.instance.insertDocument(doc.toMap());
    state = [doc, ...state]; // Prepend for immediate update
  }

  Future<void> removeDocument(Document doc) async {
    // Remove from DB
    await DatabaseHelper.instance.deleteDocument(doc.id);
    // Remove from State
    state = state.where((element) => element.id != doc.id).toList();
    // Delete file from local storage to save space
    try {
      final file = dart_io.File(doc.filePath);
      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      // Intentionally ignore delete errors, focus is local SQLite DB
    }
  }
}
