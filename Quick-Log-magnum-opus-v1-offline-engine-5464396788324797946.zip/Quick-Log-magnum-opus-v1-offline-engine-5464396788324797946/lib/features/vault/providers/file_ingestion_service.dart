import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:uuid/uuid.dart';

import '../domain/document.dart';
import 'vault_provider.dart';

class IsIngestingNotifier extends Notifier<bool> {
  @override
  bool build() => false;

  void set(bool value) {
    state = value;
  }
}

final isIngestingProvider = NotifierProvider<IsIngestingNotifier, bool>(() {
  return IsIngestingNotifier();
});

final fileIngestionServiceProvider = Provider((ref) {
  return FileIngestionService(ref);
});

class FileIngestionService {
  final Ref _ref;

  FileIngestionService(this._ref);

  Future<void> ingestPdf() async {
    _ref.read(isIngestingProvider.notifier).set(true);
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );

      if (result != null && result.files.single.path != null) {
        String originalPath = result.files.single.path!;
        File originalFile = File(originalPath);

        // Calculate size in MB
        final bytes = await originalFile.length();
        final sizeMb = bytes / (1024 * 1024);

        // Get app document directory
        final appDir = await getApplicationDocumentsDirectory();
        final fileName = path.basename(originalPath);

        // Avoid naming collisions
        final uuid = const Uuid().v4();
        final savedFilePath = path.join(appDir.path, '${uuid}_$fileName');

        // Copy file
        File savedFile = await originalFile.copy(savedFilePath);

        // Headless PDF loading for total_pages extraction
        int totalPages = 0;
        try {
          final fileBytes = await savedFile.readAsBytes();
          final PdfDocument document = PdfDocument(inputBytes: fileBytes);
          totalPages = document.pages.count;
          document.dispose(); // Immediate dispose to clear memory
        } catch (e) {
          // If we fail to read it via syncfusion, keep 0 to not fail entirely
        }

        final document = Document(
          id: uuid,
          title: fileName,
          filePath: savedFilePath,
          fileSizeMb: sizeMb,
          totalPages: totalPages,
          lastAccessed: DateTime.now(),
        );

        // Update Riverpod state and SQLite
        await _ref.read(vaultProvider.notifier).addDocument(document);
      }
    } finally {
      _ref.read(isIngestingProvider.notifier).set(false);
    }
  }
}
